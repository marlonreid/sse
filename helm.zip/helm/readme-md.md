# Production-Ready AKS Helm Chart

This Helm chart deploys a production-ready API to Azure Kubernetes Service (AKS) with enterprise-grade security, scalability, and observability features.

## Features

### 🔐 Security
- **Azure Workload Identity** for keyless authentication
- **CSI Secret Store** integration with Azure Key Vault
- **Network Policies** for micro-segmentation
- **Pod Security Context** hardening (non-root, read-only filesystem)
- **Security scanning** annotations

### 🚀 Scalability & Availability
- **Horizontal Pod Autoscaling** with CPU, memory, and custom metrics
- **Pod Disruption Budgets** for high availability
- **Node affinity and tolerations** for optimal placement
- **Rolling updates** with configurable strategy

### 🌐 Networking
- **Application Gateway for Containers** ingress
- **TLS termination** and SSL redirect
- **Health probe** configuration
- **Connection draining** support

### 📊 Observability
- **Prometheus metrics** integration
- **Health checks** (liveness, readiness, startup probes)
- **Structured logging** configuration
- **Resource monitoring** with limits and requests

## Prerequisites

1. **AKS Cluster** with the following add-ons:
   - Azure Workload Identity
   - CSI Secret Store Driver
   - Application Gateway for Containers

2. **Azure Resources**:
   - Azure Key Vault
   - Managed Identity
   - Application Gateway for Containers

3. **Helm 3.x** installed

## Quick Start

### 1. Clone and Setup

```bash
# Create the chart
helm create my-helm-chart

# Replace the generated files with the production-ready templates
# Copy all files from this repository to your chart directory
```

### 2. Azure Setup

#### Create Managed Identity
```bash
# Create managed identity
az identity create --name "my-api-identity" --resource-group "my-rg"

# Get the client ID
IDENTITY_CLIENT_ID=$(az identity show --name "my-api-identity" --resource-group "my-rg" --query clientId -o tsv)
```

#### Setup Key Vault Permissions
```bash
# Grant Key Vault access to managed identity
az keyvault set-policy --name "my-keyvault" \
  --object-id $(az identity show --name "my-api-identity" --resource-group "my-rg" --query principalId -o tsv) \
  --secret-permissions get list
```

#### Create Federated Identity Credential
```bash
# Create federated identity credential for Workload Identity
az identity federated-credential create \
  --name "my-api-federated-credential" \
  --identity-name "my-api-identity" \
  --resource-group "my-rg" \
  --issuer "https://oidc.prod-aks.azure.com/YOUR_TENANT_ID/" \
  --subject "system:serviceaccount:default:my-api-service-account"
```

### 3. Configure Values

Update `values.yaml` with your specific configuration:

```yaml
# Image configuration
image:
  repository: myregistry.azurecr.io/my-api
  tag: "v1.0.0"

# Azure Workload Identity
workloadIdentity:
  enabled: true
  tenantId: "your-tenant-id"
  clientId: "your-managed-identity-client-id"

# Key Vault configuration
secrets:
  enabled: true
  keyVault:
    name: "my-keyvault"
    tenantId: "your-tenant-id"

# Ingress configuration
ingress:
  enabled: true
  hosts:
    - host: api.example.com
      paths:
        - path: /
          pathType: Prefix
```

### 4. Deploy

```bash
# Install with default values
helm install my-api ./my-helm-chart

# Install with production values
helm install my-api ./my-helm-chart -f values-prod.yaml

# Upgrade
helm upgrade my-api ./my-helm-chart -f values-prod.yaml
```

## Configuration

### Core Configuration

| Parameter | Description | Default |
|-----------|-------------|---------|
| `image.repository` | Container image repository | `myregistry.azurecr.io/my-api` |
| `image.tag` | Container image tag | `latest` |
| `replicaCount` | Number of replicas | `3` |

### Azure Workload Identity

| Parameter | Description | Default |
|-----------|-------------|---------|
| `workloadIdentity.enabled` | Enable Azure Workload Identity | `true` |
| `workloadIdentity.tenantId` | Azure tenant ID | `""` |
| `workloadIdentity.clientId` | Managed identity client ID | `""` |

### Secret Management

| Parameter | Description | Default |
|-----------|-------------|---------|
| `secrets.enabled` | Enable CSI Secret Store | `true` |
| `secrets.keyVault.name` | Azure Key Vault name | `""` |
| `secrets.secretObjects` | Secret objects to sync | See values.yaml |

### Autoscaling

| Parameter | Description | Default |
|-----------|-------------|---------|
| `autoscaling.enabled` | Enable HPA | `true` |
| `autoscaling.minReplicas` | Minimum replicas | `3` |
| `autoscaling.maxReplicas` | Maximum replicas | `10` |
| `autoscaling.targetCPUUtilizationPercentage` | Target CPU % | `70` |

### Security

| Parameter | Description | Default |
|-----------|-------------|---------|
| `podSecurityContext.runAsNonRoot` | Run as non-root user | `true` |
| `securityContext.readOnlyRootFilesystem` | Read-only root filesystem | `true` |
| `networkPolicy.enabled` | Enable network policies | `true` |

## Production Deployment

For production deployments, use the `values-prod.yaml` file which includes:

- Higher resource limits
- More aggressive health checks
- Stricter pod disruption budgets
- Enhanced security settings
- Production-specific ingress configuration

```bash
helm install my-api ./my-helm-chart -f values-prod.yaml
```

## Monitoring

### Health Endpoints

The application should expose the following endpoints:

- `/health` - Liveness probe endpoint
- `/ready` - Readiness probe endpoint
- `/metrics` - Prometheus metrics (if enabled)

### Prometheus Integration

If you have Prometheus installed, metrics will be automatically scraped based on the pod annotations:

```yaml
podAnnotations:
  prometheus.io/scrape: "true"
  prometheus.io/port: "8080"
  prometheus.io/path: "/metrics"
```

## Troubleshooting

### Common Issues

1. **Workload Identity Not Working**
   ```bash
   # Check service account annotations
   kubectl describe sa my-api-service-account
   
   # Verify federated credential
   az identity federated-credential list --identity-name "my-api-identity" --resource-group "my-rg"
   ```

2. **Secret Store Issues**
   ```bash
   # Check SecretProviderClass
   kubectl describe secretproviderclass my-api-secrets
   
   # Check CSI driver logs
   kubectl logs -n kube-system -l app=secrets-store-csi-driver
   ```

3. **Pod Startup Issues**
   ```bash
   # Check pod events
   kubectl describe pod -l app.kubernetes.io/name=my-helm-chart
   
   # Check container logs
   kubectl logs -l app.kubernetes.io/name=my-helm-chart
   ```

### Debugging Commands

```bash
# Check all resources
kubectl get all -l app.kubernetes.io/instance=my-api

# Check HPA status
kubectl get hpa

# Check network policies
kubectl get networkpolicy

# Check pod disruption budgets
kubectl get pdb

# Test connectivity
kubectl run test-pod --rm -i --tty --image=busybox -- /bin/sh
```

## Security Best Practices

This chart implements several security best practices:

1. **Non-root containers** - All containers run as non-root user (65534)
2. **Read-only root filesystem** - Prevents runtime file system modifications
3. **Dropped capabilities** - Removes all Linux capabilities
4. **Network segmentation** - Network policies restrict traffic
5. **Resource limits** - Prevents resource exhaustion
6. **Security contexts** - Enforces security policies
7. **Workload Identity** - Keyless authentication to Azure services

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test the changes
5. Submit a pull request

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Support

For support and questions:

- Create an issue in the repository
- Contact the DevOps team at devops@example.com
- Check the documentation at https://docs.example.com