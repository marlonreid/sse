# Production-Ready AKS Helm Chart

This Helm chart deploys an API to Azure Kubernetes Service (AKS) with enterprise-grade features including CSI Secret Store integration, Azure Workload Identity, Application Gateway for Containers, and comprehensive hardening.

## Chart Structure

```
my-helm-chart/
├── Chart.yaml
├── values.yaml
├── values-prod.yaml
├── templates/
│   ├── deployment.yaml
│   ├── service.yaml
│   ├── ingress.yaml
│   ├── serviceaccount.yaml
│   ├── hpa.yaml
│   ├── pdb.yaml
│   ├── networkpolicy.yaml
│   ├── secretproviderclass.yaml
│   ├── configmap.yaml
│   └── NOTES.txt
└── README.md
```

## Key Features

- **Azure Workload Identity** integration for secure, keyless authentication
- **CSI Secret Store** integration with Azure Key Vault
- **Application Gateway for Containers** ingress
- **Horizontal Pod Autoscaling** with custom metrics
- **Pod Disruption Budgets** for high availability
- **Network Policies** for micro-segmentation
- **Security Context** hardening
- **Resource limits and requests**
- **Health checks** (readiness, liveness, startup probes)
- **Rolling updates** with proper deployment strategies
- **Node affinity and tolerations**

## Installation

```bash
# Install with default values
helm install my-api ./my-helm-chart

# Install with production values
helm install my-api ./my-helm-chart -f values-prod.yaml

# Upgrade
helm upgrade my-api ./my-helm-chart -f values-prod.yaml
```

## Configuration

See `values.yaml` for all configuration options. Key sections include:

- `image`: Container image configuration
- `workloadIdentity`: Azure Workload Identity settings
- `secrets`: Azure Key Vault integration
- `ingress`: Application Gateway for Containers configuration
- `autoscaling`: HPA configuration
- `podDisruptionBudget`: Availability settings
- `networkPolicy`: Network security rules
- `securityContext`: Pod and container security settings